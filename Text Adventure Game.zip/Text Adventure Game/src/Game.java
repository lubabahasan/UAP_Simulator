import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Game {
   
    Container container;
    JFrame mainWindow;
    JPanel titlePanel, startButtonPanel, storyPanel, choicePanel, inputTextPanel, inputPanel, contButtonPanel;
    JPanel choiceButtonPanel, playerStatsPanel;
    JButton startButton, enter, contButton, choice1, choice2, choice3, choice4;
    JLabel titleText, timeLabel, timeValue, attndLabel, attndValue, cgpaLabel, cgpaValue, friendsLabel, friendsValue;
    JTextArea storyText, inputText;
    JTextField inputField;

    Dimension size = Toolkit.getDefaultToolkit().getScreenSize(); 
    int width = (int)size.getWidth(); 
    int height = (int)size.getHeight();

    Font titleFont = new Font("Impact", Font.PLAIN, (int)Math.ceil(height/9.6));
    Font buttonFont = new Font("Garamond", Font.PLAIN, (int)Math.ceil(height/28.8));
    Font choiceFont = new Font("Garamond", Font.BOLD, (int)Math.ceil(height/28.8));
    Font normalFont = new Font("Calisto MT", Font.PLAIN, (int)Math.ceil(height/23));
    Font smallNormalFont = new Font("Calisto MT", Font.PLAIN, (int)Math.ceil(height/25));

    int time = 1000, attendance = 0, friend = 0;
    float CGPA = 0.00f;
    String studentName, club = "", awards = "";
    
    String text;
    int i = 0, flag = 0;
    
    MainScreenHandler actionHandler = new MainScreenHandler();
    InputHandler inputHandler = new InputHandler();
    ContinueHandler continueHandler = new ContinueHandler();
    ChoiceHandler choiceHandler = new ChoiceHandler();
    
    public static void main(String[] args) {
        Game game = new Game();
    }
    
    public Game(){
        
        mainWindow = new JFrame();
        mainWindow.setExtendedState(JFrame.MAXIMIZED_BOTH); //fullscreen
        mainWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //exits program by closing the window
        mainWindow.getContentPane().setBackground(Color.decode("#280a68")); //sets background colour
        mainWindow.setLayout(null); //for custom layout
        mainWindow.setVisible(true); //make it appear on screen
        container = mainWindow.getContentPane(); //for title screen
        
        //title panel
        titlePanel = new JPanel(); //new panel
        titlePanel.setBounds((int)Math.ceil(width/4.8), (int)Math.ceil(height/4.32), (int)Math.ceil(width/1.71), (int)Math.ceil(height/7.2)); //panel resolution
        titlePanel.setBackground(Color.decode("#a70c70")); //panel background colour
        
        //title text
        titleText = new JLabel("U A P  S I M U L A T O R"); //setting title text
        titleText.setForeground(Color.white); //title tex colour setting
        titleText.setFont(titleFont); //assingng font properties
        
        //start button panel
        startButtonPanel = new JPanel();
        startButtonPanel.setBounds((int)Math.ceil(width/2.6), (int)Math.ceil(height/2.16), (int)Math.ceil(width/4.9548), (int)Math.ceil(height/7.2));
        startButtonPanel.setBackground(Color.decode("#280a68"));
        
        //start button
        startButton = new JButton("S T A R T  G A M E");
        startButton.setBackground(Color.decode("#280a68"));
        startButton.setForeground(Color.white);
        startButton.setFont(buttonFont);
        startButton.setPreferredSize(new Dimension((int)Math.ceil(width/5.12), (int)Math.ceil(height/10.8)));
        startButton.addActionListener(actionHandler);
        startButton.setFocusPainted(false);
        
        //Adding Labels to Panels
        titlePanel.add(titleText); //adding title text to panel
        startButtonPanel.add(startButton);
        
        //Adding panels to screen
        container.add(titlePanel);
        container.add(startButtonPanel);
        SwingUtilities.updateComponentTreeUI(mainWindow);
        
    }
    
    Timer timer1 = new Timer(5, new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e) {
            char character[] = text.toCharArray();
            int arrayLen = character.length;
            String s = String.valueOf(character[i]);
            inputText.append(s);
            i++;
            if(i == arrayLen){
                i = 0;
                timer1.stop();
            }
        }
    });
    
    Timer timer2 = new Timer(5, new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e) {
            char character[] = text.toCharArray();
            int arrayLen = character.length;
            String s = String.valueOf(character[i]);
            storyText.append(s);
            i++;
            if(i == arrayLen){
                i = 0;
                contButtonPanel.add(contButton);
                container.add(contButtonPanel);
                flag = 1;
            }
            if(flag==1){
                SwingUtilities.updateComponentTreeUI(mainWindow);
                timer2.stop();
            }
        }
    });
    
    Timer timer3 = new Timer(5, new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e) {
            char character[] = text.toCharArray();
            int arrayLen = character.length;
            String s = String.valueOf(character[i]);
            storyText.append(s);
            i++;
            if(i == arrayLen){
                i = 0;
                timer3.stop();
            }
        }
    });
    
    public void studentSetup(){
        timeValue.setText(""+time);
        attndValue.setText(""+attendance);
        cgpaValue.setText(""+CGPA);
        friendsValue.setText(""+friend);
    }
    
    public void introduction(){
        titlePanel.setVisible(false);
        startButtonPanel.setVisible(false);
       
        //Input Text Panel
        inputTextPanel = new JPanel();
        inputTextPanel.setBounds((int)Math.ceil(width/7.2), (int)Math.ceil(height/5.0), (int)Math.ceil(width/1.3), (int)Math.ceil(height/4.32));
        inputTextPanel.setBackground(Color.decode("#280a68"));
        
        //Input Text
        text = "Please enter your name: ";
        inputText = new JTextArea();
        inputText.setBounds((int)Math.ceil(width/7.2), (int)Math.ceil(height/5.0), (int)Math.ceil(width/1.3), (int)Math.ceil(height/4.32));
        inputText.setBackground(Color.decode("#280a68"));
        inputText.setForeground(Color.white);
        inputText.setFont(normalFont);
        inputText.setLineWrap(true);
        inputText.setWrapStyleWord(true);
        inputTextPanel.add(inputText);
        container.add(inputTextPanel);
        timer1.start();
        
        //Input Panel
        inputPanel = new JPanel();
        inputPanel.setBounds((int)Math.ceil(width/5.1), (int)Math.ceil(height/2.16), (int)Math.ceil(width/1.6), (int)Math.ceil(height/10.8));
        inputPanel.setBackground(Color.black);
        inputPanel.setLayout(new GridLayout(1,2));
        
        //Input Field
        inputField = new JTextField();
        inputField.setFont(normalFont);
        inputField.setHorizontalAlignment(JTextField.CENTER);
        inputPanel.add(inputField);
        
        //Enter Button
        enter = new JButton("E N T E R");
        //enter.setBackground(Color.decode("#280a68"));
        enter.setForeground(Color.black);
        enter.setFont(buttonFont);
        enter.addActionListener(inputHandler);
        enter.setFocusPainted(false);
        
        inputPanel.add(enter);
        container.add(inputPanel);
    }
    
    public void stage1(){
        inputPanel.setVisible(false);
        inputTextPanel.setVisible(false);
        
        //Story Panel
        storyPanel = new JPanel();
        storyPanel.setBounds((int)Math.ceil(width/7.2), (int)Math.ceil(height/5.0), (int)Math.ceil(width/1.3), (int)Math.ceil(height/3.9));
        storyPanel.setBackground(Color.decode("#280a68"));
        
        //Body
        text = "Welcome " + studentName + "! You are a new student at the University of Asia Pacific. Explore the opportunities that lie ahead, and make wise choices as you have limited time to balance academics, extracurricular activities, and personal growth. Good Luck!";
        storyText = new JTextArea();
        storyText.setBounds((int)Math.ceil(width/7.2), (int)Math.ceil(height/4.32), (int)Math.ceil(width/1.3), (int)Math.ceil(height/3.9));
        storyText.setBackground(Color.decode("#280a68"));
        storyText.setForeground(Color.white);
        storyText.setFont(normalFont);
        storyText.setLineWrap(true);
        storyText.setWrapStyleWord(true);
        storyPanel.add(storyText);
        container.add(storyPanel);
        timer2.start();
        
        //Continue Button Panel
        contButtonPanel = new JPanel();
        contButtonPanel.setBounds((int)Math.ceil(width/2.6), (int)Math.ceil(height/2.16), (int)Math.ceil(width/4.9548), (int)Math.ceil(height/7.2));
        contButtonPanel.setBackground(Color.decode("#280a68"));
        
        //Continue Button
        contButton = new JButton("C O N T I N U E");
        contButton.setBackground(Color.decode("#280a68"));
        contButton.setForeground(Color.white);
        contButton.setFont(buttonFont);
        contButton.setPreferredSize(new Dimension((int)Math.ceil(width/5.12), (int)Math.ceil(height/10.8)));
        contButton.addActionListener(continueHandler);
        contButton.setFocusPainted(false);
    }
    
    public void stage2(){
        contButtonPanel.setVisible(false);
        
        //Top Player Stat Panel
        playerStatsPanel = new JPanel();
        playerStatsPanel.setBounds((int)Math.ceil(width/15), (int)Math.ceil(height/86.4), (int)Math.ceil(width), (int)Math.ceil(height/7.2));
        playerStatsPanel.setBackground(Color.decode("#280a68"));
        playerStatsPanel.setLayout(new GridLayout(1,8));
        
        //Adding Stat Labels to Panel
        timeLabel = new JLabel("    Time:");
        timeLabel.setFont(smallNormalFont);
        timeLabel.setForeground(Color.white);
        timeValue = new JLabel();
        timeValue.setFont(smallNormalFont);
        timeValue.setForeground(Color.white);
        
        attndLabel = new JLabel("Attendance:");
        attndLabel.setFont(smallNormalFont);
        attndLabel.setForeground(Color.white);
        attndValue = new JLabel();
        attndValue.setFont(smallNormalFont);
        attndValue.setForeground(Color.white);
        
        cgpaLabel = new JLabel("    CGPA:");
        cgpaLabel.setFont(smallNormalFont);
        cgpaLabel.setForeground(Color.white);
        cgpaValue = new JLabel();
        cgpaValue.setFont(smallNormalFont);
        cgpaValue.setForeground(Color.white);
        
        friendsLabel = new JLabel(" Friends:");
        friendsLabel.setFont(smallNormalFont);
        friendsLabel.setForeground(Color.white);
        friendsValue = new JLabel();
        friendsValue.setFont(smallNormalFont);
        friendsValue.setForeground(Color.white);
        
        playerStatsPanel.add(timeLabel);
        playerStatsPanel.add(timeValue);
        playerStatsPanel.add(attndLabel);
        playerStatsPanel.add(attndValue);
        playerStatsPanel.add(cgpaLabel);
        playerStatsPanel.add(cgpaValue);
        playerStatsPanel.add(friendsLabel);
        playerStatsPanel.add(friendsValue);
        studentSetup();
        container.add(playerStatsPanel);
        
        //Resetting Story Panel
        storyPanel.remove(storyText);
        storyPanel.revalidate();
        storyPanel = new JPanel();
        storyPanel.setBounds((int)Math.ceil(width/7.2), (int)Math.ceil(height/5.0), (int)Math.ceil(width/1.3), (int)Math.ceil(height/3.9));
        storyPanel.setBackground(Color.decode("#280a68"));

        //Body
        text = "You enter your first class at UAP. Seems like your teacher isn’t here yet.\nWhat do you want to do?";
        storyText = new JTextArea();
        storyText.setBounds((int)Math.ceil(width/7.2), (int)Math.ceil(height/4.32), (int)Math.ceil(width/1.3), (int)Math.ceil(height/3.9));
        storyText.setBackground(Color.decode("#280a68"));
        storyText.setForeground(Color.white);
        storyText.setFont(normalFont);
        storyText.setLineWrap(true);
        storyText.setWrapStyleWord(true);
        storyPanel.add(storyText);
        container.add(storyPanel);
        timer3.start();
       
        //Choice Button Panel
        choiceButtonPanel = new JPanel();
        choiceButtonPanel.setBounds((int)Math.ceil(width/3.4), (int)Math.ceil(height/2.16), (int)Math.ceil(width/2.4), (int)Math.ceil(height/4.32));
        choiceButtonPanel.setBackground(Color.decode("#280a68"));
        choiceButtonPanel.setLayout(new GridLayout(4,1));

        //Attend Button
        choice1 = new JButton("Attend Class");
        choice1.setBackground(Color.decode("#a70c70"));
        choice1.setForeground(Color.white);
        choice1.setFont(choiceFont);
        choice1.setFocusPainted(false);
        choice1.addActionListener(choiceHandler);
        choice1.setActionCommand("attend");

        //Bunk Button
        choice2 = new JButton("Bunk Class");
        choice2.setBackground(Color.decode("#a70c70"));
        choice2.setForeground(Color.white);
        choice2.setFont(choiceFont);
        choice2.setFocusPainted(false);
        choice2.addActionListener(choiceHandler);
        choice2.setActionCommand("bunk");
      
        //Adding buttons to panel
        choiceButtonPanel.add(choice1);
        choiceButtonPanel.add(choice2);
        container.add(choiceButtonPanel);
        container.add(playerStatsPanel);
        container.revalidate();

    }
    
    public void attend(){
        attendance++;
        CGPA+=0.5f;
        time-=10;
    }
    
    public void bunk(){
        time-=10;
        friend++;
        
    }
    
    public class MainScreenHandler implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent event){
            introduction();
        }
    }
    
    public class InputHandler implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent event){
            String name = inputField.getText();
            studentName = name;
            stage1();
        }
    }
    
    public class ContinueHandler implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent event){
            timer2.stop();
            stage2();
        }
    }
    
    public class ChoiceHandler implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent event){
            String choice = event.getActionCommand();
            
            switch(choice){
                case "attend":
                    attend();
                    break;
                case "bunk":
                    bunk();
                    break;
            }
        }
    }
}